﻿Public Class SplashScreen1
    Public Delegate Sub SetProgressBarDelegate(ByVal max As Integer)
    Public Delegate Sub UpdateProgressBarDelegate(ByVal value As Integer)
    ''' <summary>
    ''' Set 100% value
    ''' </summary>
    ''' <param name="MaxValue"></param>
    ''' <remarks></remarks>
    Public Sub SetMax(ByVal MaxValue As Integer)
        If Me.InvokeRequired Then
            Me.Invoke(New SetProgressBarDelegate(AddressOf SetMax), MaxValue)
        Else
            Me.ProgressBar1.Maximum = MaxValue
        End If
    End Sub
    Public Sub UpdateProgressBar(ByVal CurrentProgress As Integer)

        If Me.InvokeRequired Then
            Me.Invoke(New UpdateProgressBarDelegate(AddressOf UpdateProgressBar), CurrentProgress)
        Else
            Me.ProgressBar1.Value = CurrentProgress
            Me.Label1.Text = CurrentProgress.ToString & "% complete"
        End If
    End Sub
    Private Const CP_NOCLOSE_BUTTON As Integer = &H200
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim myCp As CreateParams = MyBase.CreateParams
            myCp.ClassStyle = myCp.ClassStyle Or CP_NOCLOSE_BUTTON
            Return myCp
        End Get
    End Property
End Class